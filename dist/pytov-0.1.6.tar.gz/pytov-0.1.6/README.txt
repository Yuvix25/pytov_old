# pytov
Python but tov (good).

## Features
* Curly braces
* No identation errors
* Long and short comments (`/**/`, `//`)
* Switch statement
* Compiles to python

## Requirements
* python 3

## How to use
First, run `$ pip install pytov`, and then, to run files, simply run in the command line `$ pytov path_to_file`.
If you want to also save the compiled python file use (`$ pytov path_to_file -py`).