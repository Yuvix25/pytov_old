# pytov
Python but tov (good).

## Getting Started
Run the setup.bat file.

## Features
* Curly braces
* No identation errors
* Long and short comments (`/**/`, `//`)
* Switch statement
* Compiles to python

## Requirements
* python 3

## How to use
To run files, **after running setup.bat (see Get Started)**, simply run in the command line `$ pytov path_to_file`.
If you want to also save the compiled python file use (`$ pytov path_to_file -py`).